package demo_final.vo;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CategoryVo {
    
    int category_idx;
    int category_code;
    String category_name;
}
