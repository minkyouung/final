package demo_final.vo;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter

public class CommentBoardVo {

    int c_b_idx;
    String c_b_content;
    String c_b_ip;
    String c_b_regdate;
    int b_idx;
    int mem_idx;
    String mem_id;
    String mem_name;

}
