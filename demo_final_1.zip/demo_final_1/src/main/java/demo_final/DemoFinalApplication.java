package demo_final;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoFinalApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoFinalApplication.class, args);
	}

}
